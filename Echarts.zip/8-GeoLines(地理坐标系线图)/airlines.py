#!/usr/bin/env python3
# coding=utf-8
__author__ = 'songshu'

import pandas as pd
from pyecharts import GeoLines,Style
from warnings import filterwarnings
from translate import Translator
filterwarnings("ignore")

# 读取数据：机场和航线数据
routes = pd.read_excel('./data/航线数据.xlsx', sheetname='routes')
airports = pd.read_excel('./data/航线数据.xlsx', sheetname='airports') \
    [['Airport ID', 'City', 'Country', 'IATA', 'Latitude', 'Longitude', 'Altitude']]

# 处理机场经纬度数据
airports_geo = airports[['City', 'Latitude', 'Longitude']]
airports_geo.index = airports_geo['City']
airports_geo = airports_geo[['Longitude', 'Latitude']]
airports_geo = airports_geo.T.to_dict(orient='list')


def getCityAirlines(city_name = "Guangzhou",airport_type = "起飞"):
    '''
    用于构造指定机场，起飞或者降落的航班
    :param city_name: 机场所在城市名称，注意第一个字母大写
    :param airport_type: ‘起飞’或者‘降落’
    :return: 返回指定城市，起飞或者降落的航班航线，list类型，如：[['Chongqing', 'Zhanjiang'], ...]
    '''

    # 提取该城市对应的机场ID，注意有的城市有多个机场
    airportID = airports[airports["City"] == city_name]['Airport ID'].tolist()

    # 返回机场起飞航班
    if airport_type == "起飞":
        source = routes[routes['Source airport ID'].isin(airportID)][['Source airport ID','Destination airport ID']]\
            .drop_duplicates()
        source["Source airport"] = city_name
        source = pd.merge(source,airports,left_on="Destination airport ID",right_on="Airport ID",how = "left")\
            [["Source airport","City"]]
        airline_source = source.values.tolist()
        return airline_source
    # 返回降落航班
    elif airport_type == "降落":
        destination = routes[routes['Destination airport ID'].isin(airportID)][['Source airport ID','Destination airport ID']]\
            .drop_duplicates()
        destination["Destination airport"] = city_name
        destination = pd.merge(destination,airports,left_on="Source airport ID",right_on="Airport ID",how = "left")\
            [["City","Destination airport"]]
        airline_destination = destination.values.tolist()
        return airline_destination
    else:
        return False



# 图形整体配置文件
style = Style(
    title_color="#fff",
    title_pos = "center",
    width=1280,
    height=720,
    background_color="#404a59"
)

# 图形局部细节配置文件
style_geo = style.add(
    maptype="world",
    is_label_show=True,
    line_curve=0.1,
    line_opacity=0.6,
    legend_text_color="#eee",
    legend_pos="right",
    geo_effect_symbol="plane",
    geo_effect_symbolsize=15,
    label_color=['#a6c84c', '#ffa022', '#46bee9'],
    label_pos="right",
    label_formatter="{b}",
    label_text_color="#eee",
    geo_cities_coords=airports_geo
)


if __name__ == '__main__':

    # 要分析的城市名称，起降类型
    city_name,airport_type = "New York","起飞"

    # 此处使用Python的谷歌翻译模块，将城市名称翻译成中文
    translator = Translator(to_lang="zh")
    translation = translator.translate(city_name)
    print(translation)

    # 获取用于绘图的数据
    select_airlines = getCityAirlines(city_name,airport_type)
    print(select_airlines[:2])

    # 绘制图形
    if select_airlines:
        geolines = GeoLines("{}{}航班的航线".format(translation,airport_type), **style.init_style)
        geolines.add(name = "",data = select_airlines,is_legend_show=False,**style_geo)
        geolines.render('./html/airlines.html')
        print("绘图完毕")